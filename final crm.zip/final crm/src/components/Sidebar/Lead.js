import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';
import { useState ,useEffect} from 'react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Lead() {
  const [data, setData] = useState([]);
	useEffect(() => {
		// fetching api of contact form from local db.json file
		fetch('http://localhost:3000/lead').then((res) => res.json()).then((response) => setData(response));
	}, [])

  
    const [leadData, setleadData] = useState({
      companyName: "",
      ProjectTitle:"",
      ProjectDescription:"",
      EstimatedMonthlyRevenue:"",
      AssignedTo:"",
      leadSource:"",
    

    
    });
    const [record, setRecord] = useState([]);

    const handleChange = (e) => {
        const name = e.target.name
        const value = e.target.value
        setleadData({ ...leadData, [name]: value });
    }
    
    const lead = async (formData) => {
        await fetch('http://localhost:3000/lead', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
            },
            body: JSON.stringify(formData),
        }).then(() => {
            toast.success("Regested successfully")
                    }).catch((e) => {
            alert("something went wrong.")
        })
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const newRec = { ...leadData };
        lead(newRec);
        setRecord([...record, newRec]);
        setleadData({
          
            companyName: "",
            ProjectTitle:"",
            ProjectDescription:"",
            EstimatedMonthlyRevenue:"",
            AssignedTo:"",
            leadSource:"",
            customerWebsite:"",
            

          
        });
alert("Lead Submitted Successfully")

    };

    
   
  return (
    <div >
<h3 className='head3'>Lead Information </h3>

<form className="row g-3  mx-0 my-0" id='dikkat'onSubmit={handleSubmit} >
<div className="col-md-3">
    <label for="inputState" className="form-label">Company Name</label>
    <select id="inputState" className="form-select" onChange={handleChange} value={leadData.companyName} autoComplete='off' name="companyName">
      <option selected>Choose...</option>
      <option>GOOGLE</option>
      <option>HCL</option>
      <option>WIPRO </option>
      <option>NIT INFOTECH</option>
      <option>TESLA</option>
      <option>ZOHO</option>
      <option>MICROSOFT</option>
      <option>FACEBOOK</option>
      <option>CAPGEMINI</option>
      <option>INFOSYS</option>
      <option>ORACALE</option>
      <option>ZEPTO</option>
      <option>MASTERCARD</option>
      <option>ZOMATO</option>
      <option>BLINKIT</option>



    </select>
  </div>
  <div className="col-md-3">
    <label for="inputEmail4" className="form-label">Project Title</label>
    <input type="text" className="form-control" id="inputEmail4" required onChange={handleChange} value={leadData.ProjectTitle} autoComplete='off' name="ProjectTitle" />
  </div>
  <div className="col-md-3">
    <label for="inputPassword4" className="form-label">Project Description</label>
    <input type="text"  className="form-control" id="inputPassword4" required  onChange={handleChange} value={leadData.ProjectDescription} autoComplete='off' name="ProjectDescription"/>
  </div>
  <div className="col-md-3">
    <label for="inputEmail4" className="form-label">Estimated Monthly Revenue</label>
    <input type="text" className="form-control" id="inputEmail4" required onChange={handleChange} value={leadData.EstimatedMonthlyRevenue} autoComplete='off' name="EstimatedMonthlyRevenue"/>
  </div>
  <div className="col-md-3">
    <label for="inputState" className="form-label">Assigned To </label>
    <select id="inputState" className="form-select" onChange={handleChange} value={leadData.AssignedTo} autoComplete='off' name="AssignedTo">
      <option selected>Choose...</option>
      <option>XYZ </option>
      <option>ABC</option>
      <option>123</option>
     

    </select>
  </div>
  <div className="col-md-3">
    <label for="inputState" className="form-label">lead Source </label>
    <select id="inputState" className="form-select" onChange={handleChange} value={leadData.leadSource} autoComplete='off' name="leadSource">
      <option selected>Choose...</option>
      <option>  LINKEDIN</option>
      <option>DIRECT</option>
      <option>GOOGLE ADWORDS</option>
      <option>AMAZON</option>
    

    </select>
  </div>
  <div className="col-md-3">
    <label for="inputEmail4" className="form-label">Customer Website</label>
    <input type="text" className="form-control" id="inputEmail4" required  autoComplete='off' name="customerWebsite" />
  </div>

  <div className="col-12">
    <div className="form-check">
      <input className="form-check-input" type="checkbox" id="gridCheck"/>
      <label className="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>
  <div className="col-12">
    <button type="submit" className="btn btn-primary" >Submit</button>
  </div>
  
</form>
<div style={{width :"40vw"}}>
<table className="table3" >
				<thead>
					<tr>
            <th>companyName</th>
						<th>ProjectTitle</th>
						<th>ProjectDescription</th>
						<th>EstimatedMonthlyRevenue</th>
						<th>AssignedTo</th>
						<th>leadSource</th>
				
					</tr>
				</thead>
				<tbody>
					{
						data.length && data.map((tbdata) => {
							const {  companyName, ProjectTitle, ProjectDescription, EstimatedMonthlyRevenue, AssignedTo, leadSource} = tbdata;
							return (
								<>
									<tr>
										<td >{companyName}</td>
										<td >{ProjectTitle}</td>
										<td >{ProjectDescription}</td>
										<td >{EstimatedMonthlyRevenue}</td>
										<td >{AssignedTo}</td>
										<td >{leadSource}</td>
									</tr>
								</>
							)
						})
					}
				</tbody>
			</table>
      </div>


    </div>


    
  )
}

export default Lead;