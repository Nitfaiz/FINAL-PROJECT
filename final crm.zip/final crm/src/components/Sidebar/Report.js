import React from 'react'
import { useState } from 'react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; 


 const Report=()=> {
  const [reportData, setreportData] = useState({
    Reason: "",
    ContactNumber:"",
    Description:"",
  });

  const [record, setRecord] = useState([]);

    const handleChange = (e) => {
        const name = e.target.name
        const value = e.target.value
        setreportData({ ...reportData, [name]: value });
    }
    
    const report = async (formData) => {
        await fetch('http://localhost:3000/report', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
            },
            body: JSON.stringify(formData),
        }).then(() => {
            toast.success("Regested successfully")
                    }).catch((e) => {
            alert("something went wrong")
        })
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const newRec = { ...reportData };
        report(newRec);
        setRecord([...record, newRec]);
        setreportData({
          
          Reason: "",
          ContactNumber:"",
          Description:"",
        });
alert("Report Submitted Successfully")

    };


  return (
    
    <div className='mobile'> 
      <form className="row g-3  mx-0 my-0" onSubmit={handleSubmit} >
      <h3 style={{marginTop :"7px",color :"green"}}>Report Here !</h3>
      <div className="col-md-6">
        
    <label for="inputState" className="form-label">Reason </label>
    <select id="inputState" className="form-select" autoComplete='off'onChange={handleChange} value={reportData.Reason}  name="Reason">
      <option selected>Choose...</option>
      <option>First</option>
      <option>Second</option>
      <option>Other</option>
   

    </select>
  </div>
  <div className="col-md-6">
    <label for="inputEmail4" className="form-label">Contact Number</label>
    <input type="text" placeholder='+91' className="form-control" id="inputEmail4" required onChange={handleChange} value={reportData.ContactNumber} autoComplete='off' name="ContactNumber"/>
  </div>


  <div class="form-group">
    <label for="exampleFormControlTextarea1">Description</label>
    <textarea placeholder='Describe Your Problem ...' class="form-control" id="exampleFormControlTextarea1" rows="3" onChange={handleChange} value={reportData.Description} autoComplete='off' name="Description"></textarea>
  </div>

  <div className="col-12">
    <button type="submit" className="btn btn-primary">Submit</button>
  </div>
</form>
    </div>
  )
}
export default Report;