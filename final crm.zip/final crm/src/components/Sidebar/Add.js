import React from "react";
import 'bootstrap/dist/css/bootstrap.css';

const Add = () => {
    return (
        <>
            <br /><h3 className="h1Customer">Address Information</h3>
            <form className="row g-3  mx-0 my-0" id='dikkat' >
            <div className="col-md-3">
                    <label for="inputEmail4" className="form-label">Department</label>
                    <input type="text" className="form-control" id="inputEmail4" required />
                </div>
                <div className="col-md-3">
                    <label for="inputEmail4" className="form-label">Skype ID</label>
                    <input type="text" className="form-control" id="inputEmail4" required />
                </div>
                <div className="col-md-3">
                    <label for="inputPassword4" className="form-label">Linkedin</label>
                    <input type="text" className="form-control" id="inputPassword4" required />
                </div>
                
            </form>

        </>

    )
}
export default Add;