import React from 'react'


export default function Dashboard() {
  return (
    <div><h2><i>This Is Dashboard Page</i></h2></div>
  )
}

