import React from 'react'

function Sms() {
  return (
    <div>Sms me on 9889897976</div>
  )
}

export default Sms