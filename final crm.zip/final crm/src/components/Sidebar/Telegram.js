import React from 'react'

function Telegram() {
  return (
    <div>Telegram Channel Name is Thapa technical</div>
  )
}

export default Telegram