import React from 'react'

function Email() {
  return (
    <div>

<h3 className='head3'> Enter Your Email Here !</h3>
<div className="col-md-12">
    <label for="inputEmail4" className="form-label">Email ID</label>
    <input type="text" placeholder='your123@gmail.com' className="form-control" id="inputEmail4" required autoComplete='off'/>
  </div>

    </div>
  )
}

export default Email