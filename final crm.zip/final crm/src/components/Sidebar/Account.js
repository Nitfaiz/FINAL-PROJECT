import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';
import { useState,useEffect } from 'react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Account() {
  const [data, setData] = useState([]);
	useEffect(() => {
		// fetching api of contact form from local db.json file
		fetch('http://localhost:3000/about').then((res) => res.json()).then((response) => setData(response));
	}, [])
  
    const [adminData, setadminData] = useState({
      FirstName: "",
      LastName: "",
      DOB: "",
      ContactNumber: "",
      UserName: "",  
      Password:"",
      ConfirmPassword:"",
      Email:"",
    
    });
    const [record, setRecord] = useState([]);

    const handleChange = (e) => {
        const name = e.target.name
        const value = e.target.value
        setadminData({ ...adminData, [name]: value });
    }
    
    const admin = async (formData) => {
        await fetch('http://localhost:3000/about', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
            },
            body: JSON.stringify(formData),
        }).then(() => {
            toast.success("Regested successfully")
                    }).catch((e) => {
            alert("something went wrong.")
        })
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const newRec = { ...adminData };
        admin(newRec);
        setRecord([...record, newRec]);
        setadminData({
          FirstName: "",
          MiddleName:"",
          LastName: "",
          DOB: "",
          Photo: "",
          ContactNumber: "",
          UserName: "",  
          Password:"",
          ConfirmPassword:"",
        });
        alert("form has been Submitted successfully")
    };

   
  return (
    <div >
<h3 className='head3'> Account Information </h3>

<form className="row g-3  mx-0 my-0" id='dikkat'onSubmit={handleSubmit} >
  <div className="col-md-4">
    <label for="inputEmail4" className="form-label">First Name</label>
    <input type="text" className="form-control" id="inputEmail4" required onChange={handleChange} value={adminData.FirstName} autoComplete='off' name="FirstName" />
  </div>
  <div className="col-md-4">
    <label for="inputEmail4" className="form-label">Middle Name</label>
    <input type="text" className="form-control" id="inputEmail4" required autoComplete='off'  />
  </div>
  <div className="col-md-4">
    <label for="inputEmail4" className="form-label">Last Name</label>
    <input type="text" className="form-control" id="inputEmail4" required onChange={handleChange} value={adminData.LastName} autoComplete='off' name="LastName" />
  </div>
  
  <div className="col-md-4">
    <label for="inputPassword4" className="form-label">DOB</label>
    <input type="date"  className="form-control" id="inputPassword4" required onChange={handleChange} value={adminData.DOB} autoComplete='off' name="DOB" />
  </div>
 
  <div className="col-md-4">
    <label for="inputEmail4" className="form-label">Contact Number</label>
    <input type="number" className="form-control" id="inputEmail4" required onChange={handleChange} value={adminData.ContactNumber} autoComplete='off' name="ContactNumber"/>

    
  </div>
  <div className="col-md-4">
    <label for="inputPassword4" className="form-label">Email ID</label>
    <input type="email" placeholder='example@gmail.com' className="form-control" id="inputPassword4" required  autoComplete='off'/>
  </div>
  

  <div className="col-md-4">
    <label for="inputPassword4" className="form-label">User Name</label>
    <input type="text" className="form-control" id="inputPassword4" required onChange={handleChange} value={adminData.UserName} autoComplete='off' name="UserName"/>
  </div>
  <div className="col-md-4">
    <label for="inputPassword4" className="form-label">Password</label>
    <input type="password" className="form-control" id="inputPassword4" required onChange={handleChange} value={adminData.Password} autoComplete='off' name="Password"/>
  </div>
  <div className="col-md-4">
    <label for="inputPassword4" className="form-label"> Confirm Password</label>
    <input type="password" className="form-control" id="inputPassword4" required onChange={handleChange} value={adminData.ConfirmPassword} autoComplete='off' name="ConfirmPassword"/>
  </div>
  
 
  
  
  
  

  <div className="col-12">
    <div className="form-check">
      <input className="form-check-input" type="checkbox" id="gridCheck"/>
      <label className="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>
  <div className="col-12">
    <button type="submit" className="btn btn-primary">Submit</button>
  </div>
  
</form>

<div style={{width :"40vw"}}>
<table className="table3" >
				<thead>
					<tr>
            <th>FirstName</th>
						<th>LastName</th>
						<th>DOB</th>
						<th>ContactNumber</th>
						<th>UserName</th>
						<th>Password</th>
				
					</tr>
				</thead>
				<tbody>
					{
						data.length && data.map((tbdata) => {
							const {  FirstName, LastName, DOB, ContactNumber, UserName, Password} = tbdata;
							return (
								<>
									<tr>
										<td >{FirstName}</td>
										<td >{LastName}</td>
										<td >{DOB}</td>
										<td >{ContactNumber}</td>
										<td >{UserName}</td>
										<td >{Password}</td>
									</tr>
								</>
							)
						})
					}
				</tbody>
			</table>
      </div>













    </div>


    
  )
}

export default Account;