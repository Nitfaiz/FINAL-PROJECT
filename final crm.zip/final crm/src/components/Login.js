import React from 'react'
import { NavLink,useNavigate} from "react-router-dom";
import { useState } from "react";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Login() {
    const gotoHome = useNavigate ();
    const auth =()=>{
gotoHome("/home");
    }

    const [signinData, setSigninData] = useState({
    
        email: "",
        password: ""
    
    });
    const [record, setRecord] = useState([]);

    const handleChange = (e) => {
        const name = e.target.name
        const value = e.target.value
        setSigninData({ ...signinData, [name]: value });
        // console.log(signupData.firstname);
    }
    const User = async (formData) => {
        await fetch(
            `http://localhost:3000/users?email=${formData.email}&password=${formData.password}`,
            {
                method: "GET",
                headers: {
                    "Content-type": "application/json",
                }
            }).then((res) => res.json())
            .then((res) => {
                if (res.length) {
                    console.log(res);
                    setSigninData({
                        ...signinData,
                        login: "success",
                    })
                    localStorage.setItem("isLogin", true);

                    toast.success("Login successfully");
                    auth();
                    

                } else {
                    toast.error("Invalid Credentials")
                }
            })
            .catch((error) => {
                throw error
            });
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        const newRec = { ...signinData };
        User(newRec);
        // console.log(newRec);
        setRecord([...record, newRec]);
        setSigninData({
          
            email:"",
            password: "",
          
        });
        // console.log(record);
        alert("LogedIn Successfully")
    };

    
  return (
  



<div className="doColor">
            <div className="container doCenter">
                <section className="vh-100">
                    <div className="container-fluid h-custom">
                        <div className="row d-flex justify-content-center align-items-center h-100">
                            <div className="col-md-9 col-lg-6 col-xl-5">
                                <img
                                    src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.webp"
                                    className="img-fluid"
                                    alt="Sample"
                                    height= "100px"
                                />
                            </div>
                            <div className="col-md-8 col-lg-6 col-xl-4 offset-xl-1 doShadow">
                                <form  onSubmit={handleSubmit}>
                                    <p className="log">
                                        <span style={{ color: "Black" }}>Si</span>
                                        <span style={{ color: "blue" }}>gn</span>
                                        <span style={{ color: "green" }}>-In</span>
                                    </p>
                                    {/* Email input */}

                                    <div className="form-outline mb-2">
                                    <label className="form-label" htmlFor="form3Example3">
                                            Email address
                                        </label>
                                        <input
                                            type="email"
                                            name="email"
                                            id="form3Example3"
                                            className="form-control form-control-lg"
                                            placeholder="Enter a valid Email address"
                                            autoComplete='off'
                                            style={{fontFamily :"auto"}}
                                            value={signinData.email}

                                            required
                                            onChange={handleChange}
                                        />
                                        
                                    </div>
                                    {/* Password input */}
                                    <div className="form-outline mb-2">
                                    <label className="form-label" htmlFor="form3Example4">
                                            Password
                                        </label>
                                        <input
                                            name="password"
                                            type="password"
                                            autoComplete='off'
                                            id="form3Example4"
                                            className="form-control form-control-lg"
                                            style={{fontFamily :"auto"}}
                                            placeholder="Enter password"
                                            onChange={handleChange}
                                            value={signinData.password}
                                            required
                                        />
                                        
                                    </div>

                                    <div className="d-flex justify-content-between align-items-center"></div>
                                    <div className="text-center text-lg-start mt-0 pt-2">
                                        <button
                                            className="btn btn-primary btn-lg col-12 mb-0"
                                            style={{ paddingLeft: "2.5rem", paddingRight: "2.5rem" }}
                                            type="submit"
                                           
                                        >
                                           Login

                                        </button>
                                        <p className="small fw-bold mt-2 pt-1 mb-0" style={{textDecoration:"none"}}>
                                            
                                           Not a Member ?{" "}
                                            <NavLink to="/signup" className="link-danger">
                                                SignUp
                                            </NavLink>
                                        </p>
                                        <br />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <ToastContainer />
                </section>
            </div>
        </div>






 
  )
}
export default Login;
