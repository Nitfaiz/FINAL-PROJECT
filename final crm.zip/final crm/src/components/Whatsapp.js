import React from 'react'

function Whatsapp() {
  return (
    <div>Whatsapp me : https://87879274837856.whatsapp.com</div>
  )
}

export default Whatsapp